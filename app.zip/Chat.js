import React, { useState, useEffect, useRef } from "react";

import {
  View,
  Text,
  Image,
  Alert,
  FlatList,
  Keyboard,
  Vibration,
  TextInput,
  StyleSheet,
  TouchableOpacity,
} from "react-native";

// import Video from "react-native-video";
import Icon from "react-native-vector-icons/Ionicons";
import Icon1 from "react-native-vector-icons/MaterialCommunityIcons";

///////////////////////////////////////////////////////////////////////

const ChatWindow = () => {
  let [chat, setChat] = useState([
    {
      sender: "bot",
      message: "say hai to continue",
    },
  ]);
  let [inputMessage, setInputMessage] = useState("");
  let [botTyping, setbotTyping] = useState();
  let flatListRef = useRef(null);
  const name = "varun";

  //----------//

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      "keyboardDidShow",
      () => {
        flatListRef.current.scrollToEnd();
      }
    );

    return () => {
      keyboardDidShowListener.remove();
    };
  }, []);

  useEffect(() => {
    console.log("called");
  }, [chat]);

  //----------//

  const rasaAPI = async function handleClick(name, msg) {
    await fetch(
      "https://0dd4-49-205-84-132.in.ngrok.io/webhooks/rest/webhook",
      {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          charset: "UTF-8",
        },
        credentials: "same-origin",
        body: JSON.stringify({ sender: name, message: msg }),
      }
    )
      .then((response) => response.json())
      .then((response) => {
        if (response) {
          for (let i = 0; i < response.length; i++) {
            const temp = response[i];
            let recipient_msg;
            const recipient_id = temp["recipient_id"];

            if (temp.hasOwnProperty("text")) {
              recipient_msg = temp["text"];
            }

            const response_temp = {
              sender: "bot",
              recipient_id: recipient_id,
              message: recipient_msg,
            };

            if (temp.hasOwnProperty("buttons")) {
              response_temp["buttons"] = temp["buttons"];
            }

            setChat((chat) => [...chat, response_temp]);
          }

          setbotTyping(false);
          flatListRef.current.scrollToEnd();
          // scrollBottom();
        }
      });
  };

  const handleSubmit = (evt) => {
    evt.preventDefault();
    const request_temp = {
      sender: "user",
      sender_id: name,
      message: inputMessage,
    };

    if (inputMessage !== "") {
      setChat((chat) => [...chat, request_temp]);
      setbotTyping(true);
      setInputMessage("");
      rasaAPI(name, inputMessage);
    } else {
      window.alert("Please enter valid message");
    }
    Vibration.vibrate(50);
  };

  const handleButton = (e) => {
    const request_temp = {
      sender: "user",
      sender_id: name,
      message: e,
    };
    setChat((chat) => [...chat, request_temp]);
    rasaAPI(name, e);
  };

  const renderItem = ({ item }) => {
    return (
      <View
        style={{
          alignSelf: item["sender"] === "bot" ? "flex-start" : "flex-end",
          margin: 5,
        }}
      >
        <Text style={styles.chatText}>{item.message}</Text>

        {item.hasOwnProperty("buttons") ? (
          <View>
            {item.buttons.map((button, index) => (
              <View style={styles.btnsView}>
                <Icon1 name="arrow-right-bottom" size={15} color="white" />
                <TouchableOpacity
                  style={styles.btns}
                  key={index}
                  onPress={() => handleButton(button.payload)}
                >
                  <Text style={styles.btnsText}>{button.title}</Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>
        ) : null}
      </View>
    );
  };

  //----------//

  return (
    <View style={{ marginTop: 20 }}>
      <FlatList
        ref={flatListRef}
        data={chat}
        renderItem={renderItem}
        style={{ flexDirection: "column" }}
      />

      <View style={styles.buttonTextView}>
        <TextInput
          value={inputMessage}
          onFocus={() => flatListRef.current.scrollToEnd()}
          style={styles.textBox}
          onChangeText={(e) => {
            setInputMessage(e);
          }}
        />
        <TouchableOpacity style={styles.sendButton} onPress={handleSubmit}>
          <Icon name="send" size={20} color="white" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

///////////////////////////////////////////////////////////////////////

export default ChatWindow;

///////////////////////////////////////////////////////////////////////

const styles = StyleSheet.create({
  sendButton: {
    width: 40,
    height: 40,
    borderRadius: 50,
    borderWidth: 1,
    backgroundColor: "grey",
    borderColor: "white",
    alignItems: "center",
    justifyContent: "center",
    marginLeft: 5,
  },
  textBox: {
    borderColor: "white",
    borderWidth: 1,
    width: 350,
    height: 40,
    borderRadius: 12,
    color: "white",
    backgroundColor: "grey",
    padding: 7,
  },
  buttonTextView: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginBottom: 20,
    marginTop: 25,
  },
  chatText: {
    backgroundColor: "grey",
    padding: 8,
    borderRadius: 13,
    color: "white",
  },
  chatImg: {
    height: 150,
    width: 300,
    borderRadius: 12,
  },

  btnsText: {
    fontSize: 11,
    backgroundColor: "grey",
    marginTop: 8,
    marginLeft: 10,
    padding: 8,
    borderRadius: 13,
    color: "white",
  },
  btnsView: { flexDirection: "row", alignItem: "center" },
});
